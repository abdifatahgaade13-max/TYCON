import os


from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	PDFSearchTool,
	CSVSearchTool,
	TXTSearchTool,
	DOCXSearchTool,
	ScrapeWebsiteTool,
	ExaSearchTool
)






@CrewBase
class Project247AiSupportHubCopyCrew:
    """Project247AiSupportHubCopy crew"""

    
    @agent
    def customer_support_ticket_intake_classification_specialist(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["customer_support_ticket_intake_classification_specialist"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def customer_support_knowledge_base_research_specialist(self) -> Agent:
        
        
        embedding_config_pdfsearchtool = dict(
            embedding_model=dict(
                provider="openai",
                config=dict(
                    model="gpt-4.1",
                ),
            ),
        )
        
        embedding_config_csvsearchtool = dict(
            embedding_model=dict(
                provider="openai",
                config=dict(
                    model="gpt-4.1",
                ),
            ),
        )
        
        embedding_config_txtsearchtool = dict(
            embedding_model=dict(
                provider="openai",
                config=dict(
                    model="gpt-4.1",
                ),
            ),
        )
        
        embedding_config_docxsearchtool = dict(
            embedding_model=dict(
                provider="openai",
                config=dict(
                    model="gpt-4.1-mini",
                ),
            ),
        )
        
        return Agent(
            config=self.agents_config["customer_support_knowledge_base_research_specialist"],
            
            
            tools=[				PDFSearchTool(config=embedding_config_pdfsearchtool),
				CSVSearchTool(config=embedding_config_csvsearchtool),
				TXTSearchTool(config=embedding_config_txtsearchtool),
				DOCXSearchTool(config=embedding_config_docxsearchtool),
				ScrapeWebsiteTool(),
				ExaSearchTool()],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def customer_support_response_writer(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["customer_support_response_writer"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def support_escalation_notification_specialist(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["support_escalation_notification_specialist"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            apps=[
                    "google_gmail/send_email",
                    ],
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def customer_support_analytics_knowledge_gap_analyst(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["customer_support_analytics_knowledge_gap_analyst"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            apps=[
                    "google_sheets/append_values",
                    
                    "google_sheets/get_values",
                    ],
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    

    
    @task
    def classify_support_ticket(self) -> Task:
        return Task(
            config=self.tasks_config["classify_support_ticket"],
            markdown=False,
            
            
        )
    
    @task
    def research_knowledge_base_for_resolution(self) -> Task:
        return Task(
            config=self.tasks_config["research_knowledge_base_for_resolution"],
            markdown=False,
            
            
        )
    
    @task
    def draft_customer_response(self) -> Task:
        return Task(
            config=self.tasks_config["draft_customer_response"],
            markdown=False,
            
            
        )
    
    @task
    def escalate_if_required(self) -> Task:
        return Task(
            config=self.tasks_config["escalate_if_required"],
            markdown=False,
            
            
        )
    
    @task
    def log_analytics_generate_insights_report(self) -> Task:
        return Task(
            config=self.tasks_config["log_analytics_generate_insights_report"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the Project247AiSupportHubCopy crew"""

        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,

            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


